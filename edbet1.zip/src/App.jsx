import React, { useState } from "react";

function Header() {
  return (
    <header className="bg-casinoPurple text-white p-4 flex justify-between items-center">
      <h1 className="text-3xl font-bold text-casinoGold tracking-wide drop-shadow-lg">
        Edbet<span className="text-white">1</span>
      </h1>
      <nav className="space-x-4">
        <a href="#" className="hover:text-casinoGold">Cassino</a>
        <a href="#" className="hover:text-casinoGold">Cassino Ao Vivo</a>
        <a href="#" className="hover:text-casinoGold">Promoções</a>
        <a href="#" className="hover:text-casinoGold">Suporte</a>
        <a href="#" className="hover:text-casinoGold">Conta</a>
      </nav>
    </header>
  );
}

function Cassino() {
  const jogos = ["Roleta", "Blackjack", "Bacará", "Caça-níqueis", "Poker"];
  return (
    <section className="p-8">
      <h2 className="text-2xl font-bold text-casinoGold mb-4">Cassino Online</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {jogos.map((jogo, idx) => (
          <div key={idx} className="p-6 bg-gray-800 rounded-xl text-center shadow-lg hover:scale-105 transition">
            <h3 className="text-lg font-semibold">{jogo}</h3>
            <button className="mt-3 px-3 py-1 bg-gradient-to-r from-casinoPurple to-casinoGold text-white rounded-lg shadow-md">
              Jogar
            </button>
          </div>
        ))}
      </div>
    </section>
  );
}

function Conta() {
  const [saldo, setSaldo] = useState(100);
  return (
    <section className="p-8 bg-gray-900 rounded-xl m-4 text-center">
      <h2 className="text-xl font-bold text-casinoGold mb-2">Minha Conta</h2>
      <p>Saldo: <span className="text-casinoGold font-semibold">R${saldo}</span></p>
      <div className="mt-3 space-x-2">
        <button onClick={() => setSaldo(saldo + 50)} className="px-4 py-2 bg-gradient-to-r from-casinoPurple to-casinoGold text-white font-semibold rounded-xl shadow-lg">
          Depositar R$50
        </button>
        <button onClick={() => setSaldo(saldo - 20)} className="px-4 py-2 bg-red-600 text-white rounded-xl shadow-lg">
          Apostar R$20
        </button>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="p-4 bg-casinoPurple text-casinoGold text-center mt-8 font-semibold">
      © 2025 Edbet1 – Cassino Online
    </footer>
  );
}

export default function App() {
  return (
    <div className="min-h-screen flex flex-col bg-[#0f0a1e] text-white">
      <Header />
      <main className="flex-grow">
        <Cassino />
        <Conta />
      </main>
      <Footer />
    </div>
  );
}